package no.hvl.dat102;

public class hash {
	
	public static void main(String[] args) {
		String ab = "ab";
		String entotre = "123";
		
		System.out.println(ab.hashCode());
		System.out.println(entotre.hashCode());
	}

}
